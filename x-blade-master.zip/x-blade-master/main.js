import './src/fonts.css';
import './src/normalize.css';
import './style.css';
import './src/button.css';
import './src/header.css';
import './src/main.css';
import './src/advantages.css';
import './src/video.css';
import './src/technology.css';
import './src/reviews.css';
import './src/characteristics.css';
import './src/selection.css';
import './src/footer.css';


import './assets/src/logo.svg';
import './assets/src/phone.svg';